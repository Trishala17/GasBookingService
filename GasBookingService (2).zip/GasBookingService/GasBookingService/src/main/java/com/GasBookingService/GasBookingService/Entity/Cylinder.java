package com.GasBookingService.GasBookingService.Entity;

import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Cylinder {

    private int cylinderId;
    private String type;
    private float weight;
    private String strapColor;
    private float price;
}
