package com.GasBookingService.GasBookingService.Entity;

import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
public class GasBooking {

    private int gasBookingId;
    private int customerId;
    private LocalDate bookingDate;
    private boolean status;
    private float bill;
}
