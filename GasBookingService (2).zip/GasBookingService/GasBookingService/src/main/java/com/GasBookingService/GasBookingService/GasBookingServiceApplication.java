package com.GasBookingService.GasBookingService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GasBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GasBookingServiceApplication.class, args);
	}

}
