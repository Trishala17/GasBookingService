package com.GasBookingService.GasBookingService.Entity;


import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Customer {

    private int customerId;
    private int cylinderId;
    private int bankID;
    private int accountNo;
    private String ifscNo;
    private String pan;

}
