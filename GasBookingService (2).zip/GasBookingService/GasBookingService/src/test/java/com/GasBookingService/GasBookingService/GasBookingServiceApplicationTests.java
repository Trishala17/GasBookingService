package com.GasBookingService.GasBookingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
