package org.example;

import javax.xml.stream.events.Characters;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        //System.out.println("Hello world!");
    String input="Trishala";
    Map<Characters, Long> duplicates= input.chars()
            .mapToObj(c->(char)c)
            .collect(Collectors.groupingBy(c->c, Collectors.counting()))
            .entrySet().stream()
            .filter(e->e.getValue()>1)
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))
            .forEach((key,value)->System.out.println(key+ ":" +value));
    }
}